export enum OrderBy {
  DESC = 'DESC',
  ASC = 'ASC',
}
