export enum MomentStatus {
  avaiable,
  reserved,
}
