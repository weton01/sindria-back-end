import * as dot from 'dotenv';

dot.config();

export const envs = process.env;
