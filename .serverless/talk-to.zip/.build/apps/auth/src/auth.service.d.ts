export declare class AuthService {
    getHello(): string;
}
