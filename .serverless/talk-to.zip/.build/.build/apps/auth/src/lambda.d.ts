export var __esModule: boolean;
export function handler(event: any, context: any): Promise<any>;
