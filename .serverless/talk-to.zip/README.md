
## Start

```bash
$ nest start your-service-name --watch
```


## Create service

```bash
$ nest generate app new-service-name

// remember, if you delete any service, do you need to delete these service in nest-cli.json
```

## Nestjs docs 

https://docs.nestjs.com/