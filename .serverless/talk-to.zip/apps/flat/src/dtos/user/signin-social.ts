import { OmitType } from '@nestjs/swagger';
import { UserDto } from './user';

export class SignUpSocialDto extends UserDto{
  
}