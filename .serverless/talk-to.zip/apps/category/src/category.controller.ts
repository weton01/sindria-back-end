import { Body, Controller, Delete, Get, Param, Patch, Post } from '@nestjs/common';
import { CategoryService } from './category.service';
import { CreateCategoryDto } from './dtos/create';
import { CreateSubCategoryDto } from './dtos/create-sub';

@Controller('category')
export class CategoryController {
  constructor(private readonly categoryService: CategoryService) { }

  @Get()
  async getCategoeries(): Promise<any> {
    return await this.categoryService.find()
  }

  @Get()
  async getCategoryById(): Promise<any> {
    return
  }

  @Post()
  async createCategory(@Body() dto: CreateCategoryDto): Promise<any> {
    return await this.categoryService.create(dto)
  }

  @Post('/:id')
  async createSubCategory(@Param('id') id, @Body() dto: CreateSubCategoryDto): Promise<any> {
    return await this.categoryService.createSub(id, dto)
  }

  @Patch()
  async updateCategory() {
    return
  }

  @Delete()
  async deleteCategory() {
    return
  }
}
