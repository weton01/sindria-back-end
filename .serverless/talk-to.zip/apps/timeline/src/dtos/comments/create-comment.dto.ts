import { CommentDto } from './comment.dto';

export class CreateCommentDto extends CommentDto { }
