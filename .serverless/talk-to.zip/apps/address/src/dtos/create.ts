import { AddressDto } from './adddress';

export class CreateAddressDto extends AddressDto {}
