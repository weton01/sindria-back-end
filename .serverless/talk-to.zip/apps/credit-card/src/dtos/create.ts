import { CreditCardDto } from './credit-card';

export class CreateCreditCardDto extends CreditCardDto {}
